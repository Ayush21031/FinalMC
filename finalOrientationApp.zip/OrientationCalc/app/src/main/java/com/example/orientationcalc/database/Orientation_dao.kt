package com.example.orientationcalc.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface Orientation_dao {
    @Insert
    suspend fun insertOrientationData(orientationData: OrientationData)

    @Query("SELECT * FROM orientation_data ORDER BY timestamp ASC")
    suspend fun getAllOrientationData(): List<OrientationData>
}