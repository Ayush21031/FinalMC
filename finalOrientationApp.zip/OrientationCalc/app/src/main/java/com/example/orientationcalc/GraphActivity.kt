package com.example.orientationcalc

import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember

import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import co.yml.charts.axis.AxisData
import co.yml.charts.common.extensions.formatToSinglePrecision
import co.yml.charts.ui.linechart.LineChart
import co.yml.charts.ui.linechart.model.GridLines
import co.yml.charts.ui.linechart.model.IntersectionPoint
import co.yml.charts.ui.linechart.model.Line
import co.yml.charts.ui.linechart.model.LineChartData
import co.yml.charts.ui.linechart.model.LinePlotData
import co.yml.charts.ui.linechart.model.LineStyle
import co.yml.charts.ui.linechart.model.LineType
import co.yml.charts.ui.linechart.model.SelectionHighlightPoint
import co.yml.charts.ui.linechart.model.SelectionHighlightPopUp
import co.yml.charts.ui.linechart.model.ShadowUnderLine
import com.example.orientationcalc.database.OrientationData

import com.example.orientationcalc.ui.theme.OrientationCalcTheme
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Date
import java.util.Locale

class GraphActivity : ComponentActivity(){
    private val orientationViewModel: Orientation_view by viewModels()

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            OrientationCalcTheme { // Ensure your theme function is correctly named
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    GraphDataDisplay_1(orientationViewModel)
                }
            }
        }
    }
}

@Composable
fun GraphDataDisplay_1(orientationViewModel: Orientation_view) {
    val data = orientationViewModel.allOrientationData.observeAsState().value
    val pitchPoints = remember { mutableStateListOf<Point>() }
    val rollPoints = remember { mutableStateListOf<Point>() }
    val yawPoints = remember { mutableStateListOf<Point>() }

    LaunchedEffect(data) {
        data?.let {
            if (data.isNotEmpty()) {
                pitchPoints.clear()
                rollPoints.clear()
                yawPoints.clear()

                data.forEach { orientationData ->
                    // Convert timestamp to seconds since epoch
                    val timestampSeconds = orientationData.timestamp/1000
                    pitchPoints.add(Point(timestampSeconds, orientationData.pitch.toFloat()))
                    rollPoints.add(Point(timestampSeconds, orientationData.roll.toFloat()))
                    yawPoints.add(Point(timestampSeconds, orientationData.yaw.toFloat()))
                }
            }
        }
    }

    if (pitchPoints.isNotEmpty() && rollPoints.isNotEmpty() && yawPoints.isNotEmpty()) {
        Log.d("GraphDataDisplay", "Pitch Points: ${pitchPoints.joinToString()}")
//        Column {
//            SingleLineChartWithDateTime_pitch(pitchPoints)
//            SingleLineChartWithDateTime_roll(rollPoints)
//            SingleLineChartWithDateTime_yaw(yawPoints)
//        }
        LazyColumn(modifier = Modifier.fillMaxHeight()
            .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text(
                    text = "Pitch Chart",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                SingleLineChartWithDateTime_pitch(pitchPoints)
            }
            item {
                Text(
                    text = "Roll Chart",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                SingleLineChartWithDateTime_roll(rollPoints)
            }
            item {
                Text(
                    text = "Yaw Chart",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                SingleLineChartWithDateTime_yaw(yawPoints)
            }
        }
//        SingleLineChartWithDateTime_pitch(pitchPoints)
    } else {
        Text("Loading Data")
    }
}

@Composable
fun SingleLineChartWithDateTime_pitch(pitchPoints: List<Point>) {
    val xAxisData = AxisData.Builder()
        .axisStepSize(60.dp) // Adjust as needed
        .backgroundColor(Color.Transparent)
        .labelAndAxisLinePadding(15.dp)
//        .steps(calculateSteps(pitchPoints))
        .steps(pitchPoints.size - 1)
        .labelData { i ->
//            val startTimestamp = pitchPoints.minByOrNull { it.dateTime }?.dateTime ?: 0L
//            val timestamp = startTimestamp + (i * 10000) // Add 10 seconds for each step
//            val formatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
//            formatter.format(Date(timestamp))

            pitchPoints[i].dateTime.toString()
        }
        .labelAndAxisLinePadding(15.dp)
        .build()

    val yAxisData = AxisData.Builder()
        .steps(10)
        .backgroundColor(Color.Transparent)
        .labelAndAxisLinePadding(20.dp)
        .labelData { i ->
            val yScale = 100f / 10
            (i * yScale).formatToSinglePrecision().toString()

        }
//        .labelData { i ->
//            val yMin = pitchPoints.minOf { it.value }
//            val yMax = pitchPoints.maxOf { it.value }
//            val yScale = (yMax - yMin) / 10
//            (yMin + (i * yScale)).formatToSinglePrecision().toString()
//        }
        .build()

    val lineChartData = LineChartData(
        linePlotData = LinePlotData(
            lines = listOf(
                Line(
                    dataPoints = pitchPoints.map { co.yml.charts.common.model.Point(it.dateTime.toFloat() / 1000, it.value) },
                    LineStyle(
                        lineType = LineType.SmoothCurve(isDotted = false)
                    ),
                    IntersectionPoint(),
                    SelectionHighlightPoint(),
                    ShadowUnderLine(
                        color = Color.Green
                    ),
                    SelectionHighlightPopUp()
                )
            ),
        ),
        xAxisData = xAxisData,
        yAxisData = yAxisData,
        gridLines = GridLines(),
        backgroundColor = Color.White
    )

    LineChart(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp),
        lineChartData = lineChartData
    )
}

//
@Composable
fun SingleLineChartWithDateTime_roll(rollPoints: List<Point>){
    val xAxisData = AxisData.Builder()
        .axisStepSize(60.dp) // Adjust as needed
        .backgroundColor(Color.Transparent)
        .labelAndAxisLinePadding(15.dp)

        .steps(rollPoints.size - 1)
        .labelData { i ->
            rollPoints[i].dateTime.toString()
        }
        .labelAndAxisLinePadding(15.dp)
        .build()

    val yAxisData = AxisData.Builder()
        .steps(10)
        .backgroundColor(Color.Transparent)
        .labelAndAxisLinePadding(20.dp)
        .labelData { i ->
            val yMin = rollPoints.minOf { it.value }
            val yMax = rollPoints.maxOf { it.value }
            val yScale = (yMax - yMin) / 10
            (yMin + (i * yScale)).formatToSinglePrecision().toString()
        }
        .build()

    val lineChartData = LineChartData(
        linePlotData = LinePlotData(
            lines = listOf(
                Line(
                    dataPoints = rollPoints.map { co.yml.charts.common.model.Point(it.dateTime.toFloat() / 1000, it.value) },
                    LineStyle(
                        lineType = LineType.SmoothCurve(isDotted = false)
                    ),
                    IntersectionPoint(),
                    SelectionHighlightPoint(),
                    ShadowUnderLine(
                        color = Color.Blue
                    ),
                    SelectionHighlightPopUp()
                )
            ),
        ),
        xAxisData = xAxisData,
        yAxisData = yAxisData,
        gridLines = GridLines(),
        backgroundColor = Color.White
    )

    LineChart(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp),
        lineChartData = lineChartData
    )
}
//
@Composable
fun SingleLineChartWithDateTime_yaw(yawPoints: List<Point>){
    val xAxisData = AxisData.Builder()
        .axisStepSize(60.dp) // Adjust as needed
        .backgroundColor(Color.Transparent)
        .labelAndAxisLinePadding(15.dp)

        .steps(yawPoints.size - 1)
        .labelData { i ->
            yawPoints[i].dateTime.toString()
        }
        .labelAndAxisLinePadding(15.dp)
        .build()

    val yAxisData = AxisData.Builder()
        .steps(10)
        .backgroundColor(Color.Transparent)
        .labelAndAxisLinePadding(20.dp)
        .labelData { i ->
            val yMin = yawPoints.minOf { it.value }
            val yMax = yawPoints.maxOf { it.value }
            val yScale = (yMax - yMin) / 10
            (yMin + (i * yScale)).formatToSinglePrecision().toString()
        }
        .build()

    val lineChartData = LineChartData(
        linePlotData = LinePlotData(
            lines = listOf(
                Line(
                    dataPoints = yawPoints.map { co.yml.charts.common.model.Point(it.dateTime.toFloat() / 1000, it.value) },
                    LineStyle(
                        lineType = LineType.SmoothCurve(isDotted = false)
                    ),
                    IntersectionPoint(),
                    SelectionHighlightPoint(),
                    ShadowUnderLine(
                        color = Color.Red
                    ),
                    SelectionHighlightPopUp()
                )
            ),
        ),
        xAxisData = xAxisData,
        yAxisData = yAxisData,
        gridLines = GridLines(),
        backgroundColor = Color.White
    )

    LineChart(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp),
        lineChartData = lineChartData
    )
}

data class Point(val dateTime: Long, val value: Float)
