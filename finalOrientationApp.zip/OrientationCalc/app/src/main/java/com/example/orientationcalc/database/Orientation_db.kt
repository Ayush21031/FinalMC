package com.example.orientationcalc

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.orientationcalc.database.OrientationData
import com.example.orientationcalc.database.Orientation_dao

@Database(entities = [OrientationData::class], version = 1, exportSchema = false)
abstract class Orientation_db : RoomDatabase() {
    abstract fun orientationDao(): Orientation_dao

    companion object {
        @Volatile
        private var INSTANCE: Orientation_db? = null

        fun getDatabase(context: Context): Orientation_db {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    Orientation_db::class.java,
                    "orientation_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
