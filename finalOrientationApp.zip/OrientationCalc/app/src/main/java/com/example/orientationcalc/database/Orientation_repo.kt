package com.example.orientationcalc

import android.content.Context
import com.example.orientationcalc.database.OrientationData
import com.example.orientationcalc.database.Orientation_dao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class Orientation_repo(context: Context) {
    private val orientationDao: Orientation_dao = Orientation_db.getDatabase(context).orientationDao()

    suspend fun insertOrientationData(orientationData: OrientationData) {
        withContext(Dispatchers.IO) {
            orientationDao.insertOrientationData(orientationData)
        }
    }

    suspend fun getAllOrientationData(): List<OrientationData> {
        return withContext(Dispatchers.IO) {
            orientationDao.getAllOrientationData()
        }
    }
}
