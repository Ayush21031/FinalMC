package com.example.orientationcalc

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat.startActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModelProvider
import com.example.orientationcalc.database.OrientationData
import com.example.orientationcalc.ui.theme.OrientationCalcTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private lateinit var orientationViewModel: Orientation_view

    private var pitch by mutableStateOf(0f)
    private var roll by mutableStateOf(0f)
    private var yaw by mutableStateOf(0f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        orientationViewModel = ViewModelProvider(this).get(Orientation_view::class.java)

        setContent {
            OrientationCalcTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    OrientationDataDisplay(pitch, roll, yaw, orientationViewModel)
                }
            }
        }

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        startRepeatingTask()
    }

    private fun startRepeatingTask() {
        CoroutineScope(Dispatchers.IO).launch {
            while(true) {
                val currentTime = System.currentTimeMillis()
                val orientationData = OrientationData(
                    pitch = pitch, roll = roll, yaw = yaw, timestamp = currentTime)
                orientationViewModel.insertOrientationData(orientationData)
                delay(5000) // Wait for 10 seconds
            }
        }
    }

    override fun onResume() {
        super.onResume()
        accelerometer?.let { sensor ->
//            sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL)
            sensorManager.registerListener(this, sensor, 1000000) //microseconds
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[2]
            pitch = Math.toDegrees(Math.atan(-x / Math.sqrt((y * y + z * z).toDouble()))).toFloat()
            roll = Math.toDegrees(Math.atan(y / Math.sqrt((x * x + z * z).toDouble()))).toFloat()
            yaw = Math.toDegrees(Math.atan(Math.sqrt((x * x + y * y).toDouble()) / z.toDouble())).toFloat()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Handle accuracy changes here if needed
    }
}

@Composable
fun OrientationDataDisplay(pitch: Float, roll: Float, yaw: Float, orientationViewModel: Orientation_view) {
    val data = orientationViewModel.allOrientationData.observeAsState().value
    val context = LocalContext.current // Obtain the current context
    Surface {
//        Column(modifier = Modifier.fillMaxWidth(),
//            horizontalAlignment = Alignment.CenterHorizontally,) {
//            Text("Pitch")
//            Text("$pitch")
//            Text("Roll")
//            Text("$roll")
//            Text("Yaw")
//            Text("$yaw")
//            Button(onClick = {
//                val intent = Intent(context, GraphActivity::class.java)
//                context.startActivity(intent)
//            }) {
//                Text("Show Graphs")
//            }
//
//            Button(onClick = {
//                savedatabasetotext(context, orientationViewModel, data)
//            }) {
//                Text("Save to text")
//            }
//        }
        Column(modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier.fillMaxWidth().border(1.dp, Color.Black).padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Pitch", color = Color.Red, textAlign = TextAlign.Center)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier.fillMaxWidth().border(1.dp, Color.Black).padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("$pitch", color = Color.Red, textAlign = TextAlign.Center)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier.fillMaxWidth().border(1.dp, Color.Black).padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Roll", color = Color.Blue, textAlign = TextAlign.Center)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier.fillMaxWidth().border(1.dp, Color.Black).padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("$roll", color = Color.Blue, textAlign = TextAlign.Center)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier.fillMaxWidth().border(1.dp, Color.Black).padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Yaw", color = Color.Green, textAlign = TextAlign.Center)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier.fillMaxWidth().border(1.dp, Color.Black).padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("$yaw", color = Color.Green, textAlign = TextAlign.Center)
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = {
                val intent = Intent(context, GraphActivity::class.java)
                context.startActivity(intent)
            }) {
                Text("Show Graphs")
            }

            Button(onClick = {
                savedatabasetotext(context, orientationViewModel, data)
            }) {
                Text("Save to text")
            }
        }


    }
}

fun savedatabasetotext(context: Context, orientationViewModel: Orientation_view, data: List<OrientationData>?) {
    val fileName = "orientation_data.txt"
    val file = File(context.filesDir, fileName)

    try {
        val fos = FileOutputStream(file)
        val osw = OutputStreamWriter(fos)

        data?.forEach { orientationData ->
            osw.write("Timestamp: ${orientationData.timestamp}, Pitch: ${orientationData.pitch}, Roll: ${orientationData.roll}, Yaw: ${orientationData.yaw}\n")
        }

        osw.close()
        fos.close()

        // Send the file to PC
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "text/plain"
        intent.putExtra(Intent.EXTRA_STREAM, uri)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(Intent.createChooser(intent, "Send to PC"))

    } catch (e: Exception) {
        e.printStackTrace()
    }
}


//@Preview(showBackground = true)
//@Composable
//fun DefaultPreview() {
//    OrientationCalcTheme {
////        OrientationDataDisplay(0f, 0f, 0f, Orientation_view(Application()))
//    }
//}
