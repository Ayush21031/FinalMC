package com.example.orientationcalc.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orientation_data")
data class OrientationData(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pitch: Float,
    val roll: Float,
    val yaw: Float,
    val timestamp: Long = System.currentTimeMillis()
)