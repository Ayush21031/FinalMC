package com.example.orientationcalc

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.orientationcalc.database.OrientationData
import kotlinx.coroutines.launch

class Orientation_view(application: Application) : AndroidViewModel(application) {
    private val repository: Orientation_repo
    private val _allOrientationData = MutableLiveData<List<OrientationData>>()
    val allOrientationData: LiveData<List<OrientationData>> = _allOrientationData

    init {
//        val orientationDao = Orientation_db.getDatabase(application).orientationDao()
        repository = Orientation_repo(application)
        loadAllOrientationData()
    }

    fun insertOrientationData(orientationData: OrientationData) = viewModelScope.launch {
        repository.insertOrientationData(orientationData)
    }

    private fun loadAllOrientationData() = viewModelScope.launch {
        _allOrientationData.value = repository.getAllOrientationData()
    }
}
