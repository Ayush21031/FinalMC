package com.example.finalcnn

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.finalcnn.databinding.ActivityMainBinding
import com.example.finalcnn.ml.MobilenetQuantV1224
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var imageView: ImageView
    private lateinit var bitmap: Bitmap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        imageView = binding.imageView

        binding.btnGallery.setOnClickListener {
            if (checkAndRequestPermissions()) {
                openGallery()
            }
        }

        binding.btnCamera.setOnClickListener {
            if (checkAndRequestPermissions()) {
                openCamera()
            }
        }
    }

    private fun checkAndRequestPermissions(): Boolean {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA), 0)
            return false
        }
        return true
    }

    private fun openGallery() {
        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        resultLauncher.launch(galleryIntent)
    }

    private fun openCamera() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        resultLauncher.launch(cameraIntent)
    }

    private val resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val data: Intent? = result.data
            val bitmap: Bitmap? = if (data?.data != null) {
                // Handle image picked from the gallery
                val imageUri: Uri? = data.data
                MediaStore.Images.Media.getBitmap(this.contentResolver, imageUri)
            } else {
                // Handle image captured from camera
                data?.extras?.get("data") as? Bitmap
            }

            bitmap?.let {
                imageView.setImageBitmap(it)

            }



//            val imageUri: Uri? = data?.data
//            bitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, imageUri)
            imageView.setImageBitmap(bitmap)
            var timage = TensorImage(DataType.UINT8)
            timage.load(bitmap)
            timage = ImageProcessor.Builder()
                .add(ResizeOp(224, 224, ResizeOp.ResizeMethod.BILINEAR))
                .build()
                .process(timage)
            val model = MobilenetQuantV1224.newInstance(this)

// Creates inputs for reference.
            val inputFeature0 = TensorBuffer.createFixedSize(intArrayOf(1, 224, 224, 3), DataType.UINT8)
            inputFeature0.loadBuffer(timage.buffer)

// Runs model inference and gets result.
            val outputs = model.process(inputFeature0)
            val outputFeature0 = outputs.outputFeature0AsTensorBuffer.floatArray

            var indices = 0
            outputFeature0.forEachIndexed { index, value ->
                if (value > outputFeature0[indices]) {
                    indices = index
                }
            }

            var marking = application.assets.open("labels.txt").bufferedReader().readLines()



            val textView: TextView = binding.sampleText
//            textView.text = marking[indices]

            textView.text = resultFromJNI(marking[indices])
// Releases model resources if no longer used.
            model.close()


            val result = stringFromJNI()

        }
    }


    /** for the implementation of image classification using tensorflow i have taken reference from several resource including ai models
     * and main source of reference for the tensorflow implementation is https://www.youtube.com/watch?v=gVJC1j2n9tE&t=1392s
     */

    /** since the limited knowledge of ML because i have not taken ML course till now so i taken prebuild model for work from the
     * github : https://github.com/ankdesh/tflite/blob/master/Android-TensorFlow-Lite-Example/app/src/main/assets/mobilenet_quant_v1_224.tflite
     *
     */

    /**
     * A native method that is implemented by the 'finalcnn' native library,
     * which is packaged with this application.
     */
    external fun stringFromJNI(): String
    external fun resultFromJNI(result: String): String



    companion object {
        // Used to load the 'finalcnn' library on application startup.
        init {
            System.loadLibrary("finalcnn")
        }
    }
}