#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "Your-Tag", __VA_ARGS__)

JNICALL
Java_com_example_finalcnn_MainActivity_stringFromJNI(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

extern "C" JNIEXPORT jstring
JNICALL
Java_com_example_finalcnn_MainActivity_resultFromJNI(
        JNIEnv *env,
        jobject /* this */,
        jstring result) {

    const char *resultCStr = env->GetStringUTFChars(result, 0);

    std::string resultStr(resultCStr);
    std::string responseStr = "Result:" + resultStr + "FROM JNI";

    env->ReleaseStringUTFChars(result, resultCStr);

    return env->NewStringUTF(responseStr.c_str());
}

